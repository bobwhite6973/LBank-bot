function formatBalance(usdt) {
  const n = parseFloat(usdt);
  return isNaN(n) ? usdt : n.toFixed(2);
}

function formatPosition(pos) {
  const dirEmoji = pos.direction === 'LONG' ? '🟢 LONG' : '🔴 SHORT';
  const pnlSign  = pos.pnlPct >= 0 ? '+' : '';
  const pnlEmoji = pos.pnlPct >= 0 ? '📈' : '📉';
  return (
    `${dirEmoji} *${pos.symbol}* ${pos.leverage}x\n` +
    `Entry: ${pos.entryPrice?.toFixed(4) || '?'} | Now: ${pos.currentPrice?.toFixed(4) || '?'}\n` +
    `PnL: ${pnlEmoji} *${pnlSign}${pos.pnlPct?.toFixed(2)}%* (${pnlSign}$${pos.pnlUsdt?.toFixed(2)})\n` +
    `Margin: $${pos.marginUsdt?.toFixed(2)} | Sources: ${pos.sources?.join(', ') || '?'}`
  );
}

function formatTrade(trade) {
  if (trade.type === 'OPEN') {
    const dirEmoji = trade.direction === 'LONG' ? '🟢' : '🔴';
    return (
      `${dirEmoji} *${trade.direction} Opened*\n\n` +
      `Pair: *${trade.symbol}* @ ${trade.leverage}x leverage\n` +
      `Entry: ${trade.price?.toFixed(4) || 'market'}\n` +
      `Margin: $${trade.margin} | Qty: ${trade.qty}\n` +
      `Score: ${trade.score}pt | Sources: ${trade.sources?.join(' + ') || '?'}`
    );
  }

  // CLOSE
  const pnlSign  = trade.pnlPct >= 0 ? '+' : '';
  const pnlEmoji = trade.pnlUsdt >= 0 ? '📈' : '📉';
  return (
    `${pnlEmoji} *${trade.direction} Closed* — ${formatReason(trade.reason)}\n\n` +
    `Pair: *${trade.symbol}* @ ${trade.leverage}x\n` +
    `Entry: ${trade.entryPrice?.toFixed(4)} → Exit: ${trade.exitPrice?.toFixed(4)}\n` +
    `PnL: *${pnlSign}${trade.pnlPct?.toFixed(2)}%* (*${pnlSign}$${trade.pnlUsdt?.toFixed(2)}*)`
  );
}

function formatReason(reason) {
  const map = {
    stop_loss:        '🛡️ Stop Loss',
    take_profit:      '🎯 Take Profit',
    trailing_stop:    '📐 Trailing Stop',
    liquidation_guard:'⚠️ Liquidation Guard',
    manual:           '✋ Manual Close',
  };
  return map[reason] || reason;
}

function formatPnL(total, daily) {
  const ts = total >= 0 ? '+' : '';
  const ds = daily >= 0 ? '+' : '';
  const te = total >= 0 ? '📈' : '📉';
  return `${te} Total: *${ts}$${total.toFixed(2)}* | Today: *${ds}$${daily.toFixed(2)}*`;
}

module.exports = { formatBalance, formatPosition, formatTrade, formatPnL };
