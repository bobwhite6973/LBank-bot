const crypto = require('crypto');
const config = require('../config/config');

/**
 * LBankClient
 * -----------
 * Handles all communication with the LBank Contract (Futures) API.
 * Auth: HmacSHA256 signature method.
 *
 * Key endpoints used:
 *   GET  /cfd/openApi/v1/pub/instruments          — list all contracts
 *   GET  /cfd/openApi/v1/pub/ticker               — price/volume ticker
 *   GET  /cfd/openApi/v1/prv/account              — wallet balance
 *   POST /cfd/openApi/v1/prv/order                — place order
 *   POST /cfd/openApi/v1/prv/cancel               — cancel order
 *   GET  /cfd/openApi/v1/prv/position             — open positions
 *   POST /cfd/openApi/v1/prv/setLeverage          — set leverage
 */
class LBankClient {
  constructor() {
    this.apiKey    = config.LBANK_API_KEY;
    this.apiSecret = config.LBANK_API_SECRET;
    this.base      = config.LBANK_REST;
  }

  // ── signing ───────────────────────────────────────────────────────────────

  _sign(params) {
    const timestamp  = Date.now().toString();
    const echostr    = this._randomStr(36);
    const sigMethod  = 'HmacSHA256';

    // Merge all params including auth fields
    const allParams = {
      ...params,
      api_key:          this.apiKey,
      timestamp,
      echostr,
      signature_method: sigMethod,
    };

    // Sort by key name alphabetically
    const sorted = Object.keys(allParams).sort()
      .reduce((acc, k) => { acc[k] = allParams[k]; return acc; }, {});

    // Build query string
    const queryStr = Object.entries(sorted)
      .map(([k, v]) => `${k}=${v}`)
      .join('&');

    // MD5 → uppercase
    const md5 = crypto.createHash('md5').update(queryStr).digest('hex').toUpperCase();

    // HmacSHA256 of the MD5 string
    const sign = crypto.createHmac('sha256', this.apiSecret)
      .update(md5)
      .digest('hex');

    return { sign, timestamp, echostr, sigMethod };
  }

  _randomStr(len) {
    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let str = '';
    for (let i = 0; i < len; i++) str += chars[Math.floor(Math.random() * chars.length)];
    return str;
  }

  // ── HTTP helpers ──────────────────────────────────────────────────────────

  async _get(path, params = {}) {
    const { sign, timestamp, echostr, sigMethod } = this._sign(params);
    const query = new URLSearchParams({ ...params, api_key: this.apiKey, sign }).toString();
    const url   = `${this.base}${path}?${query}`;

    const res = await fetch(url, {
      headers: {
        'Content-Type':     'application/json',
        'timestamp':        timestamp,
        'signature_method': sigMethod,
        'echostr':          echostr,
      },
    });

    const data = await res.json();
    if (data.result === false) throw new Error(`LBank API error: ${data.msg} (${data.error_code})`);
    return data.data || data;
  }

  async _post(path, params = {}) {
    const { sign, timestamp, echostr, sigMethod } = this._sign(params);
    const body = JSON.stringify({ ...params, api_key: this.apiKey, sign });

    const res = await fetch(`${this.base}${path}`, {
      method:  'POST',
      headers: {
        'Content-Type':     'application/json',
        'timestamp':        timestamp,
        'signature_method': sigMethod,
        'echostr':          echostr,
      },
      body,
    });

    const data = await res.json();
    if (data.result === false) throw new Error(`LBank API error: ${data.msg} (${data.error_code})`);
    return data.data || data;
  }

  // ── public endpoints ──────────────────────────────────────────────────────

  /** Get all available perpetual contract instruments */
  async getInstruments() {
    return this._get('/cfd/openApi/v1/pub/instruments');
  }

  /** Get ticker for one or all symbols */
  async getTicker(symbol) {
    return this._get('/cfd/openApi/v1/pub/ticker', symbol ? { symbol } : {});
  }

  /** Get all tickers (for auto pair selection) */
  async getAllTickers() {
    return this._get('/cfd/openApi/v1/pub/ticker');
  }

  /** Get current mark price */
  async getMarkPrice(symbol) {
    const data = await this._get('/cfd/openApi/v1/pub/ticker', { symbol });
    return parseFloat(Array.isArray(data) ? data[0]?.lastPrice : data?.lastPrice);
  }

  // ── private account endpoints ─────────────────────────────────────────────

  /** Get USDT futures wallet balance */
  async getBalance() {
    const data = await this._get('/cfd/openApi/v1/prv/account', {
      asset:        'USDT',
      productGroup: 'SwapU',
    });
    return {
      available: parseFloat(data?.available || 0),
      balance:   parseFloat(data?.balance   || 0),
      margin:    parseFloat(data?.positionMargin || 0),
      pnl:       parseFloat(data?.unrealisedPnl  || 0),
    };
  }

  /** Get all open positions */
  async getPositions() {
    const data = await this._get('/cfd/openApi/v1/prv/position', {
      productGroup: 'SwapU',
    });
    return Array.isArray(data) ? data : (data ? [data] : []);
  }

  /** Set leverage for a symbol */
  async setLeverage(symbol, leverage) {
    return this._post('/cfd/openApi/v1/prv/setLeverage', {
      symbol,
      leverage:     leverage.toString(),
      productGroup: 'SwapU',
    });
  }

  /**
   * Place a futures order.
   * @param {object} opts
   * @param {string} opts.symbol     e.g. 'BTC_USDT'
   * @param {string} opts.side       'openLong' | 'openShort' | 'closeLong' | 'closeShort'
   * @param {string} opts.orderType  'market' | 'limit'
   * @param {number} opts.qty        number of contracts
   * @param {number} [opts.price]    required for limit orders
   */
  async placeOrder({ symbol, side, orderType = 'market', qty, price }) {
    const params = {
      symbol,
      side,
      type:         orderType,
      qty:          qty.toString(),
      productGroup: 'SwapU',
    };
    if (price) params.price = price.toString();
    return this._post('/cfd/openApi/v1/prv/order', params);
  }

  /** Cancel an open order */
  async cancelOrder(symbol, orderId) {
    return this._post('/cfd/openApi/v1/prv/cancel', {
      symbol,
      orderId,
      productGroup: 'SwapU',
    });
  }

  /** Get open orders */
  async getOpenOrders(symbol) {
    return this._get('/cfd/openApi/v1/prv/openOrders', {
      symbol,
      productGroup: 'SwapU',
    });
  }

  /** Get contract info (min qty, tick size, etc.) */
  async getContractInfo(symbol) {
    const instruments = await this.getInstruments();
    const list = Array.isArray(instruments) ? instruments : [];
    return list.find(i => i.symbol === symbol) || null;
  }

  /**
   * Calculate order qty from USDT margin amount.
   * qty = (marginUsdt * leverage) / markPrice / contractSize
   */
  async calcQty(symbol, marginUsdt, leverage) {
    const markPrice = await this.getMarkPrice(symbol);
    if (!markPrice) throw new Error(`No mark price for ${symbol}`);
    // Most LBank perpetuals: 1 contract = 0.001 BTC equivalent
    // contractSize varies — default to 1 for USDT-margined contracts
    const notional = marginUsdt * leverage;
    const qty      = notional / markPrice;
    // Round to 3 decimal places (min qty step)
    return Math.max(0.001, parseFloat(qty.toFixed(3)));
  }

  // ── top pairs by volume ───────────────────────────────────────────────────

  async getTopPairsByVolume(n = 5) {
    try {
      const tickers = await this.getAllTickers();
      const list    = Array.isArray(tickers) ? tickers : [];
      return list
        .filter(t => t.symbol?.endsWith('_USDT'))
        .sort((a, b) => parseFloat(b.turnover || 0) - parseFloat(a.turnover || 0))
        .slice(0, n)
        .map(t => t.symbol);
    } catch {
      return [];
    }
  }
}

module.exports = { LBankClient };
