const TelegramBot     = require('node-telegram-bot-api');
const { ConsensusEngine } = require('./sources/consensus');
const { TradingEngine }   = require('./trading');
const { formatBalance, formatPosition, formatTrade, formatPnL } = require('./utils');
const config = require('../config/config');

const bot      = new TelegramBot(config.TELEGRAM_TOKEN, { polling: true });
const engines  = new Map();   // chatId => TradingEngine
const consensus = new Map();  // chatId => ConsensusEngine

// ── helpers ──────────────────────────────────────────────────────────────────

function send(chatId, text, opts = {}) {
  return bot.sendMessage(chatId, text, { parse_mode: 'Markdown', ...opts });
}

function getEngine(chatId) { return engines.get(chatId); }
function getCS(chatId)     { return consensus.get(chatId); }

// ── /start /help ─────────────────────────────────────────────────────────────

bot.onText(/\/start|\/help/, (msg) => {
  const chatId = msg.chat.id;
  send(chatId,
    `📊 *LBank Leverage AutoTrader*\n\n` +
    `Automated futures trading on LBank with up to *4x leverage*.\n` +
    `Opens LONG and SHORT positions based on 5-source consensus.\n\n` +
    `*Setup*\n` +
    `/connect — Link your LBank API key\n` +
    `/balance — Check USDT futures balance\n\n` +
    `*Trading*\n` +
    `/start\\_trading — Launch all engines\n` +
    `/stop\\_trading — Stop everything\n` +
    `/status — Open positions + PnL\n` +
    `/close <symbol> — Manually close a position\n` +
    `/close\\_all — Close all positions\n` +
    `/history — Last 10 trades\n` +
    `/settings — View risk parameters\n\n` +
    `*Signal Sources*\n` +
    `/sources — Status of all 5 sources\n` +
    `/tg\\_login — Authenticate Telegram reader\n` +
    `/add\\_channel @name — Add alpha channel\n` +
    `/remove\\_channel @name — Remove channel\n` +
    `/channels — List watched channels\n` +
    `/add\\_pair BTC\\_USDT — Add trading pair\n` +
    `/pairs — List active pairs\n\n` +
    `⚡ Connect API → fund USDT futures account → /start\\_trading`
  );
});

// ── /connect ──────────────────────────────────────────────────────────────────

bot.onText(/\/connect/, (msg) => {
  const chatId = msg.chat.id;
  if (config.LBANK_API_KEY && config.LBANK_API_SECRET) {
    send(chatId,
      `✅ *LBank API Connected*\n\n` +
      `API Key: \`${config.LBANK_API_KEY.slice(0,8)}...${config.LBANK_API_KEY.slice(-4)}\`\n\n` +
      `Use /balance to verify the connection.`
    );
  } else {
    send(chatId,
      `❌ *API Key Not Set*\n\n` +
      `Add these to Railway → Variables:\n\n` +
      `\`LBANK_API_KEY\` = your API key\n` +
      `\`LBANK_API_SECRET\` = your secret key\n\n` +
      `Get them from: lbank.com → My Account → API Management\n` +
      `⚠️ Enable *Futures/Contract* permission when creating the key.`
    );
  }
});

// ── /balance ──────────────────────────────────────────────────────────────────

bot.onText(/\/balance/, async (msg) => {
  const chatId = msg.chat.id;
  const cs     = getCS(chatId);
  const client = cs ? cs.getLBankClient() : null;

  if (!client && (!config.LBANK_API_KEY || !config.LBANK_API_SECRET)) {
    return send(chatId, '❌ API not connected. Run /connect for instructions.');
  }

  try {
    // Use a temporary client if engine not running
    const { LBankClient } = require('./lbank_client');
    const c = client || new LBankClient();
    const bal = await c.getBalance();
    const eng = getEngine(chatId);

    send(chatId,
      `💰 *Futures Balance (USDT)*\n\n` +
      `Available: *$${formatBalance(bal.available)}*\n` +
      `Total:     $${formatBalance(bal.balance)}\n` +
      `In margin: $${formatBalance(bal.margin)}\n` +
      `Unrealised PnL: ${bal.pnl >= 0 ? '+' : ''}$${formatBalance(bal.pnl)}\n\n` +
      (eng ? `Trading: 🟢 Active | Trades: ${eng.tradeCount}` : `Trading: 🔴 Inactive`)
    );
  } catch (e) {
    send(chatId, `❌ Failed to fetch balance: ${e.message}\n\nCheck your API key is correct and has Futures permission.`);
  }
});

// ── /start_trading ────────────────────────────────────────────────────────────

bot.onText(/\/start_trading/, async (msg) => {
  const chatId = msg.chat.id;
  if (engines.has(chatId)) return send(chatId, '⚠️ Engine already running. Use /stop\\_trading first.');
  if (!config.LBANK_API_KEY || !config.LBANK_API_SECRET) {
    return send(chatId, '❌ API key not set. Run /connect for instructions.');
  }

  try {
    // Verify balance
    const { LBankClient } = require('./lbank_client');
    const tempClient = new LBankClient();
    const bal = await tempClient.getBalance();

    if (bal.available < config.MIN_MARGIN_USDT) {
      return send(chatId,
        `❌ *Insufficient Balance*\n\n` +
        `Available: $${formatBalance(bal.available)} USDT\n` +
        `Minimum needed: $${config.MIN_MARGIN_USDT} USDT\n\n` +
        `Transfer USDT to your LBank Futures account first.`
      );
    }

    const cs = new ConsensusEngine();
    consensus.set(chatId, cs);
    cs.start();

    const engine = new TradingEngine(cs.getLBankClient(), cs);
    engines.set(chatId, engine);

    // Signal notifications
    cs.on('signal_update', (sig) => {
      if (sig.weight >= 3 && sig.direction !== 'CONFLICT') {
        send(chatId,
          `📡 *Signal* [${sig.source.toUpperCase()} +${sig.weight}pt]\n` +
          `${sig.symbol} → ${sig.direction === 'LONG' ? '🟢 LONG' : '🔴 SHORT'}\n` +
          `_${(sig.reason || '').slice(0, 100)}_`
        );
      }
    });

    // Consensus reached
    cs.on('trade_signal', (sig) => {
      send(chatId,
        `🎯 *Consensus: ${sig.direction}!*\n\n` +
        `Pair: *${sig.symbol}*\n` +
        `Direction: ${sig.direction === 'LONG' ? '🟢 LONG' : '🔴 SHORT'}\n` +
        `Score: *${sig.totalScore}/${sig.maxScore}*\n` +
        `Leverage: *${sig.leverage}x*\n` +
        `Sources: ${sig.sources.join(' + ')}\n` +
        `Confidence: ${(sig.confidence * 100).toFixed(0)}%\n` +
        `_Opening position..._`
      );
    });

    engine.on('trade',  (trade) => send(chatId, formatTrade(trade)));
    engine.on('error',  (err)   => send(chatId, `⚠️ *Error:* ${err.message}`));

    engine.start();

    send(chatId,
      `🚀 *LBank Leverage Trader Started!*\n\n` +
      `Balance: $${formatBalance(bal.available)} USDT\n` +
      `Leverage: ${config.DYNAMIC_LEVERAGE ? '10-100x dynamic' : `${config.MAX_LEVERAGE}x fixed`}\n` +
      `Margin per trade: ${config.MARGIN_PERCENT}%\n` +
      `Max positions: ${config.MAX_POSITIONS}\n` +
      `Stop loss: ${config.STOP_LOSS_PCT}% price move\n` +
      `Take profit: ${config.TAKE_PROFIT_PCT}% price move\n` +
      `Trailing stop: ${config.TRAILING_STOP ? `✅ (${config.TRAILING_STOP_DISTANCE_PCT}%)` : '❌'}\n` +
      `Daily loss limit: $${config.MAX_DAILY_LOSS_USDT}\n\n` +
      `*Pairs:* ${config.BASE_PAIRS.join(', ')}\n` +
      `_Auto-discovering top volume pairs..._\n\n` +
      `*Sources:*\n` +
      `🟢 Price momentum (LBank ticker)\n` +
      `🟢 DEX Screener sentiment\n` +
      `🟡 Telegram channels (run /tg\\_login)\n` +
      `🟢 Order flow tracker\n` +
      `${config.MORALIS_API_KEY ? '🟢' : '🔴'} Moralis macro sentiment\n\n` +
      `Use /add\\_channel @channelname to add futures signal channels.`
    );
  } catch (e) {
    send(chatId, `❌ Failed to start: ${e.message}`);
  }
});

// ── /stop_trading ─────────────────────────────────────────────────────────────

bot.onText(/\/stop_trading/, async (msg) => {
  const chatId = msg.chat.id;
  const engine = engines.get(chatId);
  const cs     = consensus.get(chatId);
  if (!engine) return send(chatId, '⚠️ No active engine.');

  engine.stop();
  cs?.stop();
  engines.delete(chatId);
  consensus.delete(chatId);

  send(chatId,
    `🛑 *Engine Stopped*\n\n` +
    `Trades: ${engine.tradeCount}\n` +
    `${formatPnL(engine.getPnL(), engine.getDailyPnL())}\n\n` +
    `⚠️ Any open positions remain open on LBank — close them manually or use /close\\_all before stopping.`
  );
});

// ── /status ───────────────────────────────────────────────────────────────────

bot.onText(/\/status/, async (msg) => {
  const chatId = msg.chat.id;
  const engine = getEngine(chatId);
  const cs     = getCS(chatId);

  if (!engine) return send(chatId, `📊 *Status*\n\nEngine: 🔴 Inactive\n\nRun /balance to check your account.`);

  const positions = engine.getOpenPositions();
  const src = cs?.getSourceStatus();

  let posText = positions.length === 0 ? '_None_' :
    positions.map(p => formatPosition(p)).join('\n\n');

  send(chatId,
    `📊 *Status*\n\n` +
    `Engine: 🟢 Active | Uptime: ${engine.getUptime()}\n` +
    `Trades: ${engine.tradeCount}\n` +
    `${formatPnL(engine.getPnL(), engine.getDailyPnL())}\n\n` +
    `*Price feed:* ${engine.isWsConnected() ? "🟢 WebSocket (real-time)" : "🟡 REST fallback (1s)"}\n` +
    `*Sources:* momentum🟢 dex🟢 ` +
    `tg${src?.telegram.active ? '🟢' : '🟡'} ` +
    `flow🟢 moralis${src?.moralis.active ? '🟢' : '🔴'}\n\n` +
    `*Open Positions (${positions.length}):*\n${posText}`
  );
});

// ── /close <symbol> ───────────────────────────────────────────────────────────

bot.onText(/\/close (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const symbol = match[1].trim().toUpperCase().replace('/', '_');
  const engine = getEngine(chatId);
  if (!engine) return send(chatId, '⚠️ No active engine.');

  const pos = engine.getOpenPositions().find(p => p.symbol === symbol);
  if (!pos) return send(chatId, `❌ No open position on *${symbol}*.`);

  try {
    send(chatId, `⏳ Closing ${pos.direction} ${symbol}...`);
    await engine._closePosition(pos, pos.currentPrice, 'manual');
  } catch (e) {
    send(chatId, `❌ Failed to close: ${e.message}`);
  }
});

// ── /close_all ────────────────────────────────────────────────────────────────

bot.onText(/\/close_all/, async (msg) => {
  const chatId = msg.chat.id;
  const engine = getEngine(chatId);
  if (!engine) return send(chatId, '⚠️ No active engine.');

  const positions = engine.getOpenPositions();
  if (!positions.length) return send(chatId, 'No open positions.');

  send(chatId, `⏳ Closing ${positions.length} position(s)...`);
  for (const pos of positions) {
    try {
      await engine._closePosition(pos, pos.currentPrice, 'manual');
    } catch (e) {
      send(chatId, `❌ Failed to close ${pos.symbol}: ${e.message}`);
    }
  }
});

// ── /history ──────────────────────────────────────────────────────────────────

bot.onText(/\/history/, (msg) => {
  const chatId = msg.chat.id;
  const engine = getEngine(chatId);
  if (!engine) return send(chatId, '⚠️ No active engine.');
  const hist = engine.getHistory(10);
  if (!hist.length) return send(chatId, 'No trades yet.');

  const lines = hist.map((t, i) => {
    if (t.type === 'OPEN') {
      return `${i+1}. ${t.direction === 'LONG' ? '🟢' : '🔴'} OPEN ${t.symbol} ${t.leverage}x — $${t.margin}`;
    }
    const s = t.pnlUsdt >= 0 ? '+' : '';
    return `${i+1}. 🔒 CLOSE ${t.symbol} — *${s}$${t.pnlUsdt?.toFixed(2)}* (${s}${t.pnlPct?.toFixed(2)}%)`;
  }).join('\n\n');

  send(chatId, `📜 *Recent Trades*\n\n${lines}`);
});

// ── /settings ────────────────────────────────────────────────────────────────

bot.onText(/\/settings/, (msg) => {
  const chatId = msg.chat.id;
  const w = config.CONSENSUS.weights;
  send(chatId,
    `⚙️ *Settings*\n\n` +
    `*Risk*\n` +
    `Leverage: ${config.DYNAMIC_LEVERAGE ? '10-100x (dynamic)' : `${config.MAX_LEVERAGE}x fixed`}\n` +
    `Margin per trade: ${config.MARGIN_PERCENT}%\n` +
    `Max positions: ${config.MAX_POSITIONS}\n` +
    `Stop loss: ${config.STOP_LOSS_PCT}% price move\n` +
    `Take profit: ${config.TAKE_PROFIT_PCT}% price move\n` +
    `Trailing stop: ${config.TRAILING_STOP ? `${config.TRAILING_STOP_DISTANCE_PCT}%` : 'off'}\n` +
    `Liquidation guard: ${config.MAX_MARGIN_LOSS_PCT}% margin loss\n` +
    `Daily loss limit: $${config.MAX_DAILY_LOSS_USDT}\n\n` +
    `*Signal Weights*\n` +
    `Momentum: ${w.onchain}pt | DEX: ${w.dexscreener}pt\n` +
    `Telegram: ${w.telegram}pt | Order flow: ${w.whale}pt\n` +
    `Moralis: ${w.moralis}pt | Threshold: ${config.CONSENSUS.minBuyScore}pt\n\n` +
    `_Edit via Railway env vars_`
  );
});

// ── /sources ─────────────────────────────────────────────────────────────────

bot.onText(/\/sources/, (msg) => {
  const chatId = msg.chat.id;
  const cs = getCS(chatId);
  if (!cs) return send(chatId, '⚠️ Start trading first.');
  const s = cs.getSourceStatus();
  const maxScore = Object.values(config.CONSENSUS.weights).reduce((a, b) => a + b, 0);
  send(chatId,
    `📡 *Signal Sources*\n\n` +
    `Price momentum: 🟢 (${s.onchain.pairs} pairs)\n` +
    `DEX Screener: 🟢\n` +
    `Telegram channels: ${s.telegram.active ? '🟢' : '🟡'} (${s.telegram.channels?.length || 0})\n` +
    `Order flow: 🟢\n` +
    `Moralis: ${s.moralis.active ? '🟢' : '🔴'}\n\n` +
    `Threshold: ${config.CONSENSUS.minBuyScore}/${maxScore} pts to trade`
  );
});

// ── /add_pair ─────────────────────────────────────────────────────────────────

bot.onText(/\/add_pair (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const pair   = match[1].trim().toUpperCase().replace('/', '_');
  const cs = getCS(chatId);
  if (!cs) return send(chatId, '⚠️ Start trading first.');
  cs.getOnchainEngine().addSymbol(pair);
  send(chatId, `✅ Added *${pair}* to watchlist.`);
});

bot.onText(/\/pairs/, (msg) => {
  const chatId = msg.chat.id;
  const cs = getCS(chatId);
  if (!cs) return send(chatId, '⚠️ Start trading first.');
  const pairs = cs.getOnchainEngine().watchList;
  send(chatId, `📋 *Active Pairs*\n\n${pairs.map(p => `• ${p}`).join('\n')}`);
});

// ── Telegram login flow ────────────────────────────────────────────────────────

const tgLoginState = new Map();

bot.onText(/\/tg_login/, async (msg) => {
  const chatId = msg.chat.id;
  if (!config.TG_API_ID || !config.TG_API_HASH) {
    return send(chatId,
      `❌ *Missing Telegram API credentials*\n\n` +
      `1. Go to https://my.telegram.org/apps\n` +
      `2. Create an app → copy API ID and API Hash\n` +
      `3. Add to Railway as \`TG_API_ID\` and \`TG_API_HASH\`\n` +
      `4. Redeploy, then run /tg\\_login again.`
    );
  }
  tgLoginState.set(chatId, { step: 'phone' });
  send(chatId, `📱 *Telegram Login*\n\nEnter your phone number with country code:\n_(e.g. +14155552671)_`);
});

bot.on('message', async (msg) => {
  const chatId = msg.chat.id;
  const text   = msg.text;
  if (!text || text.startsWith('/')) return;
  const state = tgLoginState.get(chatId);
  if (!state) return;

  if (state.step === 'phone') {
    state.phone = text.trim();
    state.step  = 'code';
    tgLoginState.set(chatId, state);
    const cs = getCS(chatId);
    if (!cs) return send(chatId, '⚠️ Start trading engine first, then /tg\\_login.');
    try {
      await cs.getTelegramSource().requestCode(config.TG_API_ID, config.TG_API_HASH, state.phone);
      send(chatId, `📨 Code sent to *${state.phone}*. Enter it:`);
    } catch (e) {
      send(chatId, `❌ ${e.message}`);
      tgLoginState.delete(chatId);
    }
    return;
  }

  if (state.step === 'code') {
    const cs = getCS(chatId);
    if (!cs) return;
    try {
      const session = await cs.getTelegramSource().completeLogin(text.trim());
      tgLoginState.delete(chatId);
      send(chatId,
        `✅ *Authenticated!*\n\nUse /add\\_channel @channelname to add futures signal channels.\n\n` +
        `Save this to Railway as \`TG_SESSION\`:\n\`${session.slice(0, 40)}...\``
      );
    } catch (e) {
      send(chatId, `❌ Login failed: ${e.message}`);
      tgLoginState.delete(chatId);
    }
  }
});

bot.onText(/\/add_channel (.+)/, (msg, match) => {
  const chatId  = msg.chat.id;
  const channel = match[1].trim().replace('@', '').toLowerCase();
  const cs = getCS(chatId);
  if (!cs) return send(chatId, '⚠️ Start trading first.');
  const tg = cs.getTelegramSource();
  if (!tg.isReady()) return send(chatId, '⚠️ Run /tg\\_login first.');
  tg.addChannel(channel);
  send(chatId, `✅ Watching *@${channel}* for futures signals.`);
});

bot.onText(/\/remove_channel (.+)/, (msg, match) => {
  const chatId  = msg.chat.id;
  const cs = getCS(chatId);
  if (!cs) return;
  cs.getTelegramSource().removeChannel(match[1].trim().replace('@', ''));
  send(chatId, `✅ Removed.`);
});

bot.onText(/\/channels/, (msg) => {
  const chatId = msg.chat.id;
  const cs = getCS(chatId);
  if (!cs) return send(chatId, '⚠️ No active engine.');
  const list = cs.getTelegramSource().listChannels();
  send(chatId, list.length ? `📢 *Channels*\n\n${list.map(c => `• @${c}`).join('\n')}` : 'No channels yet.');
});

console.log('📊 LBank Leverage AutoTrader started — 4x leverage, LONG/SHORT, 5 signal sources.');
