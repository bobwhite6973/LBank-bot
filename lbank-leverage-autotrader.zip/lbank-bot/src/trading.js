const { EventEmitter } = require('events');
const WebSocket        = require('ws');
const config = require('../config/config');

/**
 * TradingEngine (LBank Futures) — WebSocket price feed edition
 * -------------------------------------------------------------
 * Price monitoring strategy (two layers):
 *
 *   PRIMARY:  LBank WebSocket — pushes real-time ticks (sub-100ms latency).
 *             Each open position's symbol is subscribed. Price updates trigger
 *             SL/TP/liquidation checks instantly on every tick.
 *             No REST calls consumed. No rate limit risk.
 *
 *   FALLBACK: 1-second REST poll — kicks in automatically if WebSocket
 *             disconnects or a symbol has no tick for > 3 seconds.
 *             Uses minimal REST quota (1 call/symbol/sec only while WS is down).
 *
 * At 100x leverage a 0.3% move can close a position — WebSocket is essential.
 */
class TradingEngine extends EventEmitter {
  constructor(lbankClient, consensusEngine) {
    super();
    this.client    = lbankClient;
    this.cs        = consensusEngine;

    this.running    = false;
    this.startedAt  = null;
    this.scanTimer  = null;
    this.fallbackTimer = null;  // REST fallback — only active when WS is down

    // symbol => Position
    this.positions  = new Map();
    this.history    = [];
    this.tradeCount = 0;
    this.totalPnL   = 0;
    this.dailyPnL   = 0;
    this.dailyReset = Date.now();

    // WebSocket state
    this.ws              = null;
    this.wsReady         = false;
    this.lastTickTs      = new Map();  // symbol => timestamp of last WS tick
    this.wsReconnectTimer = null;
    this.wsSubscribed    = new Set();  // symbols currently subscribed on WS
  }

  // ── lifecycle ─────────────────────────────────────────────────────────────

  start() {
    if (this.running) return;
    this.running   = true;
    this.startedAt = Date.now();

    // Listen for consensus trade signals
    this.cs.on('trade_signal', (sig) => {
      if (!this.running) return;
      this._openPosition(sig);
    });

    // Signal scan loop (for on-chain momentum)
    this.scanTimer = setInterval(async () => {
      if (!this.running) return;
      try { await this.cs.scan(); } catch (_) {}
    }, config.SCAN_INTERVAL_MS);

    // Start WebSocket price feed
    this._connectWebSocket();

    // Fallback REST monitor — fires every 1 second
    // Only does work if WS is down OR a symbol hasn't ticked in 3s
    this.fallbackTimer = setInterval(() => this._fallbackMonitor(), 1000);

    // Daily PnL reset
    setInterval(() => {
      const now = Date.now();
      if (now - this.dailyReset > 86_400_000) {
        this.dailyPnL   = 0;
        this.dailyReset = now;
      }
    }, 3_600_000);

    setTimeout(() => this.cs.scan(), 5000);
  }

  stop() {
    this.running = false;
    clearInterval(this.scanTimer);
    clearInterval(this.fallbackTimer);
    clearTimeout(this.wsReconnectTimer);
    this._closeWebSocket();
  }

  // ── WebSocket ─────────────────────────────────────────────────────────────

  _connectWebSocket() {
    if (this.ws) this._closeWebSocket();

    try {
      this.ws = new WebSocket(config.LBANK_WS);

      this.ws.on('open', () => {
        this.wsReady = true;
        console.log('[WS] connected to LBank price feed');
        // Re-subscribe to all open position symbols
        for (const symbol of this.positions.keys()) {
          this._wsSubscribe(symbol);
        }
      });

      this.ws.on('message', (raw) => {
        try {
          const msg = JSON.parse(raw);
          this._handleWsTick(msg);
        } catch (_) {}
      });

      this.ws.on('close', () => {
        this.wsReady = false;
        console.warn('[WS] disconnected — fallback REST active, reconnecting in 2s...');
        this.wsReconnectTimer = setTimeout(() => {
          if (this.running) this._connectWebSocket();
        }, 2000);
      });

      this.ws.on('error', (err) => {
        console.error('[WS] error:', err.message);
        this.wsReady = false;
      });
    } catch (err) {
      console.error('[WS] failed to connect:', err.message);
      this.wsReady = false;
    }
  }

  _closeWebSocket() {
    if (this.ws) {
      try { this.ws.terminate(); } catch (_) {}
      this.ws = null;
    }
    this.wsReady    = false;
    this.wsSubscribed.clear();
  }

  _wsSubscribe(symbol) {
    if (!this.wsReady || this.wsSubscribed.has(symbol)) return;
    // LBank WS ticker subscription format
    const sub = JSON.stringify({
      action: 'subscribe',
      subscribe: 'ticker',
      pair: symbol.toLowerCase(),
    });
    try {
      this.ws.send(sub);
      this.wsSubscribed.add(symbol);
      console.log(`[WS] subscribed: ${symbol}`);
    } catch (err) {
      console.error(`[WS] subscribe error for ${symbol}:`, err.message);
    }
  }

  _wsUnsubscribe(symbol) {
    if (!this.wsReady) return;
    const unsub = JSON.stringify({
      action: 'unsubscribe',
      subscribe: 'ticker',
      pair: symbol.toLowerCase(),
    });
    try {
      this.ws.send(unsub);
      this.wsSubscribed.delete(symbol);
    } catch (_) {}
  }

  _handleWsTick(msg) {
    // LBank WS ticker format: { type:'ticker', pair:'btc_usdt', ticker:{ latest:'65000', ... } }
    if (msg.type !== 'ticker' || !msg.pair || !msg.ticker) return;

    const symbol = msg.pair.toUpperCase();
    const price  = parseFloat(msg.ticker.latest || msg.ticker.close || 0);
    if (!price || !this.positions.has(symbol)) return;

    this.lastTickTs.set(symbol, Date.now());
    this._checkPosition(this.positions.get(symbol), price);
  }

  // ── Fallback REST monitor (1s interval) ──────────────────────────────────

  async _fallbackMonitor() {
    if (!this.running || !this.positions.size) return;

    const now = Date.now();
    for (const [symbol, pos] of this.positions) {
      // Skip if WS is healthy and ticked within last 3 seconds
      const lastTick = this.lastTickTs.get(symbol) || 0;
      if (this.wsReady && (now - lastTick) < 3000) continue;

      // WS stale or down — fetch via REST
      try {
        const price = await this.cs.getOnchainEngine().getPrice(symbol);
        if (price) this._checkPosition(pos, price);
      } catch (_) {}
    }
  }

  // ── core position check (called from both WS tick and REST fallback) ──────

  _checkPosition(pos, price) {
    if (!pos || !price) return;

    pos.currentPrice = price;

    const priceDiff = pos.direction === 'LONG'
      ? price - pos.entryPrice
      : pos.entryPrice - price;

    pos.pnlPct  = pos.entryPrice > 0 ? (priceDiff / pos.entryPrice) * 100 * pos.leverage : 0;
    pos.pnlUsdt = pos.marginUsdt * (pos.pnlPct / 100);

    // Update trailing stop
    if (config.TRAILING_STOP) {
      if (pos.direction === 'LONG' && price > (pos.highestPrice || 0)) {
        pos.highestPrice = price;
        pos.trailingSL   = price * (1 - config.TRAILING_STOP_DISTANCE_PCT / 100);
      } else if (pos.direction === 'SHORT' && price < (pos.lowestPrice || Infinity)) {
        pos.lowestPrice = price;
        pos.trailingSL  = price * (1 + config.TRAILING_STOP_DISTANCE_PCT / 100);
      }
    }

    // Auto-tightened SL/TP for high leverage
    const effectiveSL = this._effectiveSL(pos.leverage);
    const effectiveTP = effectiveSL * 2; // TP always 2x the SL distance

    const rawPct = pos.entryPrice > 0 ? ((price - pos.entryPrice) / pos.entryPrice) * 100 : 0;

    const slHit = pos.direction === 'LONG' ? rawPct <= -effectiveSL : rawPct >= effectiveSL;
    const tpHit = pos.direction === 'LONG' ? rawPct >= effectiveTP  : rawPct <= -effectiveTP;

    const trailHit = config.TRAILING_STOP && pos.trailingSL && pos.pnlPct > 0 && (
      (pos.direction === 'LONG'  && price <= pos.trailingSL) ||
      (pos.direction === 'SHORT' && price >= pos.trailingSL)
    );

    const liqGuard = pos.pnlPct <= -config.MAX_MARGIN_LOSS_PCT;

    // Prevent double-close — mark as closing
    if (pos._closing) return;

    if (liqGuard || slHit || tpHit || trailHit) {
      pos._closing = true;
      const reason = liqGuard ? 'liquidation_guard'
                   : slHit   ? 'stop_loss'
                   : tpHit   ? 'take_profit'
                   : 'trailing_stop';
      this._closePosition(pos, price, reason).catch(() => { pos._closing = false; });
    }
  }

  // Auto-tighten SL for high leverage to prevent liquidation
  // At base leverage of 4x, SL stays as configured.
  // Higher leverage = proportionally tighter SL.
  _effectiveSL(leverage) {
    if (!config.AUTO_TIGHTEN_SL) return config.STOP_LOSS_PCT;
    const base = config.STOP_LOSS_PCT * (4 / leverage);
    return Math.max(0.2, parseFloat(base.toFixed(2)));
  }

  // ── open position ─────────────────────────────────────────────────────────

  async _openPosition(signal) {
    const { symbol, direction, leverage, totalScore, sources } = signal;

    if (this.positions.has(symbol)) return;
    if (this.positions.size >= config.MAX_POSITIONS) return;
    if (this.dailyPnL <= -config.MAX_DAILY_LOSS_USDT) {
      this.emit('error', new Error(`Daily loss limit hit (${this.dailyPnL.toFixed(2)} USDT) — paused`));
      return;
    }

    try {
      const balance    = await this.client.getBalance();
      const available  = balance.available;
      if (available < config.MIN_MARGIN_USDT) return;

      const marginUsdt = available * (config.MARGIN_PERCENT / 100);
      if (marginUsdt < config.MIN_MARGIN_USDT) return;

      const lev = leverage || config.MAX_LEVERAGE;

      await this.client.setLeverage(symbol, lev);
      const qty        = await this.client.calcQty(symbol, marginUsdt, lev);
      const side       = direction === 'LONG' ? 'openLong' : 'openShort';
      const order      = await this.client.placeOrder({ symbol, side, orderType: 'market', qty });
      const entryPrice = await this.cs.getOnchainEngine().getPrice(symbol);

      const pos = {
        symbol,
        direction,
        leverage:    lev,
        entryPrice:  entryPrice || 0,
        currentPrice: entryPrice || 0,
        marginUsdt,
        qty,
        pnlPct:      0,
        pnlUsdt:     0,
        highestPrice: entryPrice || 0,
        lowestPrice:  entryPrice || 0,
        trailingSL:   null,
        openedAt:    Date.now(),
        orderId:     order?.orderId,
        sources,
        score:       totalScore,
        _closing:    false,
      };

      this.positions.set(symbol, pos);

      // Subscribe WebSocket for instant price ticks on this symbol
      this._wsSubscribe(symbol);

      this.tradeCount++;
      const trade = {
        type: 'OPEN', symbol, direction, leverage: lev,
        margin: marginUsdt.toFixed(2), qty,
        price: entryPrice, score: totalScore, sources,
        orderId: order?.orderId, ts: Date.now(),
        effectiveSL: this._effectiveSL(lev),
      };
      this.history.unshift(trade);
      this.emit('trade', trade);
    } catch (err) {
      this.emit('error', new Error(`OPEN ${direction} ${symbol} failed: ${err.message}`));
    }
  }

  // ── close position ────────────────────────────────────────────────────────

  async _closePosition(pos, currentPrice, reason) {
    try {
      const side  = pos.direction === 'LONG' ? 'closeLong' : 'closeShort';
      const order = await this.client.placeOrder({
        symbol:    pos.symbol,
        side,
        orderType: 'market',
        qty:       pos.qty,
      });

      const priceDiff = pos.direction === 'LONG'
        ? currentPrice - pos.entryPrice
        : pos.entryPrice - currentPrice;

      const pnlPct  = pos.entryPrice > 0 ? (priceDiff / pos.entryPrice) * 100 * pos.leverage : 0;
      const pnlUsdt = pos.marginUsdt * (pnlPct / 100);

      this.totalPnL += pnlUsdt;
      this.dailyPnL += pnlUsdt;
      this.positions.delete(pos.symbol);
      this._wsUnsubscribe(pos.symbol);
      this.lastTickTs.delete(pos.symbol);
      this.tradeCount++;

      const trade = {
        type: 'CLOSE', symbol: pos.symbol,
        direction: pos.direction, leverage: pos.leverage,
        entryPrice: pos.entryPrice, exitPrice: currentPrice,
        pnlPct, pnlUsdt, reason,
        orderId: order?.orderId, ts: Date.now(),
      };
      this.history.unshift(trade);
      this.emit('trade', trade);
    } catch (err) {
      this.emit('error', new Error(`CLOSE ${pos.symbol} failed: ${err.message}`));
    }
  }

  // ── getters ───────────────────────────────────────────────────────────────

  getOpenPositions() { return Array.from(this.positions.values()); }
  getHistory(n = 20) { return this.history.slice(0, n); }
  getPnL()           { return this.totalPnL; }
  getDailyPnL()      { return this.dailyPnL; }
  isWsConnected()    { return this.wsReady; }

  getUptime() {
    if (!this.startedAt) return '0s';
    const s = Math.floor((Date.now() - this.startedAt) / 1000);
    if (s < 60)   return `${s}s`;
    if (s < 3600) return `${Math.floor(s/60)}m ${s%60}s`;
    return `${Math.floor(s/3600)}h ${Math.floor((s%3600)/60)}m`;
  }
}

module.exports = { TradingEngine };
