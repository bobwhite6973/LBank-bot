/**
 * LBank Leverage AutoTrader — Configuration
 * ==========================================
 * All values readable from environment variables (Railway).
 */

module.exports = {
  // ── Telegram ───────────────────────────────────────────────────────────────
  TELEGRAM_TOKEN: process.env.TELEGRAM_TOKEN || '',          // ← REQUIRED
  TG_API_ID:      parseInt(process.env.TG_API_ID   || '0'),
  TG_API_HASH:    process.env.TG_API_HASH          || '',
  TG_SESSION:     process.env.TG_SESSION           || '',

  // ── LBank API ─────────────────────────────────────────────────────────────
  // Get from: lbank.com → My Account → API Management → Create API
  // Enable "Contract / Futures" permission when creating
  LBANK_API_KEY:    process.env.LBANK_API_KEY    || '',      // ← REQUIRED
  LBANK_API_SECRET: process.env.LBANK_API_SECRET || '',      // ← REQUIRED

  // LBank Contract (Futures) REST + WS base URLs
  LBANK_REST: 'https://lbkperp.lbank.com',
  LBANK_WS:   'wss://lbkperpws.lbank.com/ws',

  // ── Trading Pairs ─────────────────────────────────────────────────────────
  // BTC/USDT is always included. Bot also auto-selects top pairs by volume.
  BASE_PAIRS: (process.env.BASE_PAIRS || 'BTC_USDT,ETH_USDT,SOL_USDT').split(','),

  // Auto-add top N pairs by 24h volume on top of BASE_PAIRS
  AUTO_TOP_PAIRS: parseInt(process.env.AUTO_TOP_PAIRS || '5'),

  // ── Leverage ──────────────────────────────────────────────────────────────
  // Maximum leverage the bot is allowed to use (1-100)
  // LBank supports up to 125x on BTC/ETH — we cap at 100x for safety
  MAX_LEVERAGE: parseInt(process.env.MAX_LEVERAGE || '4'),

  // Dynamic leverage: scales based on signal score
  // DISABLED → always uses MAX_LEVERAGE regardless of signal strength
  // ENABLED  → uses tiered leverage (see tiers below)
  DYNAMIC_LEVERAGE: process.env.DYNAMIC_LEVERAGE !== 'false',

  // Leverage tiers — only used when DYNAMIC_LEVERAGE=true
  // Bot picks the tier whose minScore the signal score reaches or exceeds.
  // Edit MAX_LEVERAGE to cap the highest tier.
  // Example with MAX_LEVERAGE=100:
  //   Score 5-6  → 4x   (threshold just met)
  //   Score 7-8  → 10x  (moderate confidence)
  //   Score 9-10 → 25x  (strong signal)
  //   Score 11-12→ 50x  (very strong)
  //   Score 13+  → 100x (all 5 sources agree)
  LEVERAGE_TIERS: [
    { minScore: 5,  leverage: parseInt(process.env.LEV_TIER_1 || '10')  },  // threshold just met
    { minScore: 7,  leverage: parseInt(process.env.LEV_TIER_2 || '25')  },  // moderate confidence
    { minScore: 9,  leverage: parseInt(process.env.LEV_TIER_3 || '50')  },  // strong signal
    { minScore: 11, leverage: parseInt(process.env.LEV_TIER_4 || '75')  },  // very strong
    { minScore: 13, leverage: parseInt(process.env.LEV_TIER_5 || '100') },  // all sources agree
  ],

  // ── Position Sizing ───────────────────────────────────────────────────────
  // % of available USDT margin to use per trade (before leverage)
  MARGIN_PERCENT: parseFloat(process.env.MARGIN_PERCENT || '20'),

  // Maximum simultaneous open positions
  MAX_POSITIONS: parseInt(process.env.MAX_POSITIONS || '3'),

  // Minimum USDT margin per trade
  MIN_MARGIN_USDT: parseFloat(process.env.MIN_MARGIN_USDT || '5'),

  // ── Risk Management ───────────────────────────────────────────────────────
  // Stop loss % PRICE MOVE from entry.
  // ⚠️  At high leverage this closes fast:
  //     4x   → 3% price move = 12% margin loss
  //     25x  → 3% price move = 75% margin loss
  //     100x → 1% price move = 100% margin loss (liquidation!)
  // The bot auto-tightens SL at high leverage (see AUTO_TIGHTEN_SL below).
  STOP_LOSS_PCT:   parseFloat(process.env.STOP_LOSS_PCT   || '3'),
  TAKE_PROFIT_PCT: parseFloat(process.env.TAKE_PROFIT_PCT || '6'),

  // Auto-tighten SL/TP at high leverage to prevent liquidation.
  // When enabled, the bot overrides STOP_LOSS_PCT and TAKE_PROFIT_PCT
  // with tighter values proportional to the leverage used.
  // Formula: effective_sl = MAX(0.3, STOP_LOSS_PCT * (4 / leverage))
  // Examples at STOP_LOSS_PCT=3:
  //   4x   → SL stays 3%,  TP stays 6%
  //   25x  → SL = 0.5%,   TP = 1%
  //   100x → SL = 0.3%,   TP = 0.6%  (very tight — scalping mode)
  AUTO_TIGHTEN_SL: process.env.AUTO_TIGHTEN_SL !== 'false',

  // Hard liquidation guard — close position if margin loss exceeds this %
  // (safety net before exchange liquidates you)
  MAX_MARGIN_LOSS_PCT: parseFloat(process.env.MAX_MARGIN_LOSS_PCT || '20'),

  // Trailing stop: if enabled, SL moves up as position profits
  TRAILING_STOP: process.env.TRAILING_STOP !== 'false',
  TRAILING_STOP_DISTANCE_PCT: parseFloat(process.env.TRAILING_STOP_DIST || '2'),

  // Max daily loss — bot stops trading if total daily PnL drops below this (USDT)
  MAX_DAILY_LOSS_USDT: parseFloat(process.env.MAX_DAILY_LOSS || '50'),

  // ── Signal / Consensus ────────────────────────────────────────────────────
  CONSENSUS: {
    weights: {
      onchain:     parseInt(process.env.W_ONCHAIN     || '2'),
      dexscreener: parseInt(process.env.W_DEXSCREENER || '3'),
      telegram:    parseInt(process.env.W_TELEGRAM     || '4'),
      whale:       parseInt(process.env.W_WHALE        || '3'),
      moralis:     parseInt(process.env.W_MORALIS      || '2'),
    },
    minBuyScore:  parseInt(process.env.MIN_BUY_SCORE  || '5'),
    minSellScore: parseInt(process.env.MIN_SELL_SCORE || '5'),
  },

  // ── Scan intervals ────────────────────────────────────────────────────────
  SCAN_INTERVAL_MS: parseInt(process.env.SCAN_INTERVAL_MS || '30000'),
  // Position monitoring uses WebSocket (real-time) with 1s REST fallback.
  // MONITOR_INTERVAL_MS is no longer needed.

  // ── Moralis ───────────────────────────────────────────────────────────────
  MORALIS_API_KEY: process.env.MORALIS_API_KEY || '',

  // ── DEX Screener ─────────────────────────────────────────────────────────
  DEXSCREENER: {
    minVolume24hUsd: parseFloat(process.env.DS_MIN_VOLUME || '1000000'), // $1M+ for futures
    pollIntervalMs:  parseInt(process.env.DS_POLL_MS       || '60000'),
  },

  // ── Whale tracker ─────────────────────────────────────────────────────────
  WHALE: {
    minWinRate:         parseFloat(process.env.WHALE_MIN_WIN_RATE || '0.60'),
    maxWallets:         parseInt(process.env.WHALE_MAX_WALLETS     || '10'),
    discoverIntervalMs: parseInt(process.env.WHALE_DISCOVER_MS     || '300000'),
  },
};
